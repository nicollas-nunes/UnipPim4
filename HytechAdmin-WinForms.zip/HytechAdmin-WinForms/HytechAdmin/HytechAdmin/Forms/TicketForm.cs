using System.Text;
using HytechAdmin.Models;
using HytechAdmin.Services;
using HytechAdmin.UI;

namespace HytechAdmin.Forms
{
    /// <summary>Conversa de um ticket: histórico de mensagens, resposta do admin e encerramento.</summary>
    public class TicketForm : Form
    {
        private readonly ITicketService _servico;
        private readonly TicketItem _ticket;

        private Label _lblMeta = null!;
        private TextBox _txtConversa = null!;
        private TextBox _txtResposta = null!;
        private Button _btnEnviar = null!;
        private Button _btnEncerrar = null!;

        /// <summary>True se houve resposta ou encerramento (a lista deve ser recarregada).</summary>
        public bool Alterou { get; private set; }

        public TicketForm(ITicketService servico, TicketItem ticket)
        {
            _servico = servico;
            _ticket = ticket;
            MontarLayout();
            CarregarMensagens();
            AtualizarEstado();
        }

        private void MontarLayout()
        {
            Text = $"🎫 Ticket #{_ticket.Id}";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(640, 580);
            Font = Theme.FonteBase;
            BackColor = Theme.Branco;

            Controls.Add(new Label
            {
                Text = _ticket.Assunto,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Theme.RoxoEscuro,
                AutoSize = false,
                AutoEllipsis = true,
                Location = new Point(24, 16),
                Size = new Size(592, 28)
            });

            _lblMeta = new Label
            {
                ForeColor = Theme.CinzaTexto,
                Font = Theme.FonteSubtitulo,
                AutoSize = false,
                Location = new Point(24, 48),
                Size = new Size(592, 36)
            };
            Controls.Add(_lblMeta);

            _txtConversa = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Theme.CinzaFundo,
                Font = Theme.FonteBase,
                Location = new Point(24, 92),
                Size = new Size(592, 290)
            };
            Controls.Add(_txtConversa);

            Controls.Add(new Label
            {
                Text = "Sua resposta",
                Font = Theme.FonteBaseNegrito,
                AutoSize = true,
                Location = new Point(24, 394)
            });

            _txtResposta = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = Theme.FonteBase,
                Location = new Point(24, 416),
                Size = new Size(592, 90)
            };
            Controls.Add(_txtResposta);

            _btnEnviar = Theme.CriarBotaoPrimario("Enviar resposta");
            _btnEnviar.Location = new Point(24, 522);
            _btnEnviar.Click += BtnEnviar_Click;
            Controls.Add(_btnEnviar);

            _btnEncerrar = Theme.CriarBotaoSecundario("Encerrar ticket");
            _btnEncerrar.Location = new Point(24 + 150, 522);
            _btnEncerrar.Click += BtnEncerrar_Click;
            Controls.Add(_btnEncerrar);

            var btnFechar = Theme.CriarBotaoSecundario("Fechar");
            btnFechar.Location = new Point(616 - btnFechar.Width, 522);
            btnFechar.Click += (_, _) => Close();
            Controls.Add(btnFechar);

            CancelButton = btnFechar;
        }

        private void CarregarMensagens()
        {
            List<TicketMensagemItem> mensagens;
            try { mensagens = _servico.ObterMensagens(_ticket.Id); }
            catch (Exception ex) { Mensagens.Erro(this, ex); return; }

            var sb = new StringBuilder();
            foreach (var m in mensagens)
            {
                var papel = string.IsNullOrEmpty(m.Papel) ? "" : $" ({m.Papel})";
                sb.AppendLine($"[{m.DataHora:dd/MM HH:mm}] {m.Nome}{papel}");
                sb.AppendLine(m.Texto);
                sb.AppendLine();
            }
            _txtConversa.Text = sb.ToString();
            _txtConversa.SelectionStart = _txtConversa.TextLength;
            _txtConversa.ScrollToCaret();
        }

        private void AtualizarEstado()
        {
            var status = _ticket.Status switch
            {
                "aberto" => "🔴 Aberto",
                "respondido" => "🟢 Respondido",
                _ => "⚫ Encerrado"
            };
            _lblMeta.Text = $"Aluno: {_ticket.Solicitante}   ·   Para: {_ticket.Destinatario}" +
                            (string.IsNullOrEmpty(_ticket.Materia) ? "" : $"   ·   Matéria: {_ticket.Materia}") +
                            $"\nStatus: {status}   ·   Aberto em {_ticket.DataAbertura}";

            bool aberto = !_ticket.EstaFechado;
            _txtResposta.Enabled = aberto;
            _btnEnviar.Enabled = aberto;
            _btnEncerrar.Enabled = aberto;
            if (!aberto) _txtResposta.Text = "Ticket encerrado: não aceita novas mensagens.";
        }

        private void BtnEnviar_Click(object? sender, EventArgs e)
        {
            var texto = _txtResposta.Text.Trim();
            if (texto.Length == 0)
            {
                MessageBox.Show(this, "Escreva a resposta antes de enviar.", "Resposta vazia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _servico.Responder(_ticket.Id, texto);
            }
            catch (Exception ex)
            {
                Mensagens.Erro(this, ex);
                return;
            }

            Alterou = true;
            _ticket.Status = "respondido";
            _txtResposta.Clear();
            CarregarMensagens();
            AtualizarEstado();
        }

        private void BtnEncerrar_Click(object? sender, EventArgs e)
        {
            var confirmar = MessageBox.Show(this,
                "Encerrar este ticket? Depois disso ninguém poderá enviar novas mensagens.",
                "Encerrar ticket", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmar != DialogResult.Yes) return;

            try
            {
                _servico.Encerrar(_ticket.Id);
            }
            catch (Exception ex)
            {
                Mensagens.Erro(this, ex);
                return;
            }

            Alterou = true;
            _ticket.Status = "fechado";
            AtualizarEstado();
        }
    }
}
