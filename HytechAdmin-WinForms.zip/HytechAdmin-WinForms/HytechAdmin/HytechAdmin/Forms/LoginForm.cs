using HytechAdmin.Data;
using HytechAdmin.Models;
using HytechAdmin.Services;
using HytechAdmin.UI;

namespace HytechAdmin.Forms
{
    /// <summary>Login do Administrador. Contas que não estão na tabela Admin não entram.</summary>
    public class LoginForm : Form
    {
        private readonly AutenticacaoService _auth;
        private readonly TextBox _txtEmail;
        private readonly TextBox _txtSenha;

        public AdminLogado? Admin { get; private set; }

        public LoginForm(AutenticacaoService auth)
        {
            _auth = auth;

            Text = "HYTECH — Acesso do Administrador";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(380, 290);
            Font = Theme.FonteBase;
            BackColor = Theme.Branco;

            Controls.Add(new Label
            {
                Text = "🛡️ HYTECH Admin",
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = Theme.RoxoEscuro,
                AutoSize = true,
                Location = new Point(28, 22)
            });

            Controls.Add(new Label { Text = "E-mail", Font = Theme.FonteBaseNegrito, AutoSize = true, Location = new Point(28, 74) });
            _txtEmail = new TextBox { Location = new Point(28, 96), Width = 324, Font = Theme.FonteBase };
            Controls.Add(_txtEmail);

            Controls.Add(new Label { Text = "Senha", Font = Theme.FonteBaseNegrito, AutoSize = true, Location = new Point(28, 138) });
            _txtSenha = new TextBox { Location = new Point(28, 160), Width = 324, Font = Theme.FonteBase, UseSystemPasswordChar = true };
            Controls.Add(_txtSenha);

            var btnEntrar = Theme.CriarBotaoPrimario("Entrar");
            btnEntrar.Location = new Point(28, 214);
            btnEntrar.Click += BtnEntrar_Click;
            Controls.Add(btnEntrar);

            var btnCancelar = Theme.CriarBotaoSecundario("Cancelar");
            btnCancelar.Location = new Point(28 + 110, 214);
            btnCancelar.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(btnCancelar);

            AcceptButton = btnEntrar;
            CancelButton = btnCancelar;
        }

        private void BtnEntrar_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtEmail.Text) || string.IsNullOrEmpty(_txtSenha.Text))
            {
                MessageBox.Show(this, "Informe e-mail e senha.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var admin = _auth.Autenticar(_txtEmail.Text, _txtSenha.Text);
                if (admin is null)
                {
                    MessageBox.Show(this, "E-mail ou senha inválidos, ou a conta não é de administrador / está inativa.",
                        "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    _txtSenha.Clear();
                    return;
                }

                Admin = admin;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (ServicoException ex)
            {
                MessageBox.Show(this, ex.Message, "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
