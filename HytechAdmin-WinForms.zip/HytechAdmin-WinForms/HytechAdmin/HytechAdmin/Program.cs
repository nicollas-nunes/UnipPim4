using HytechAdmin.Data;
using HytechAdmin.Forms;
using HytechAdmin.Models;
using HytechAdmin.Security;
using HytechAdmin.Services;

namespace HytechAdmin
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string connectionString;
            try { connectionString = Db.LerConnectionString(); }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível ler o appsettings.json:\n" + ex.Message, "HYTECH Admin",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Sem connection string: modo demonstração (dados em memória, sem login).
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                var usuarios = new UsuarioServiceMock();
                var conteudos = new ConteudoServiceMock();
                var plataforma = new PlataformaServiceMock(usuarios, conteudos);
                var adminDemo = new AdminLogado { IdUsuario = 10, Nome = "Administrador (demo)" };
                Application.Run(new MainForm(usuarios, conteudos, plataforma, new TicketServiceMock(adminDemo), adminDemo));
                return;
            }

            // Modo banco: login obrigatório, somente quem está na tabela Admin entra.
            var db = new Db(connectionString);
            var hasher = new SenhaHasherBcrypt();

            using var login = new LoginForm(new AutenticacaoService(db, hasher));
            if (login.ShowDialog() != DialogResult.OK || login.Admin is null) return;

            var admin = login.Admin;
            Application.Run(new MainForm(
                new UsuarioServiceSql(db, hasher, admin),
                new ConteudoServiceSql(db, admin),
                new PlataformaServiceSql(db, admin),
                new TicketServiceSql(db, admin),
                admin));
        }
    }
}
