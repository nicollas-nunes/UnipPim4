using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace HytechAdmin.Data
{
    /// <summary>Erro de regra de negócio vindo do banco (RAISERROR das procedures) ou falha de acesso.</summary>
    public class ServicoException : Exception
    {
        public ServicoException(string mensagem, Exception? inner = null) : base(mensagem, inner) { }
    }

    /// <summary>Acesso ao SQL Server via stored procedures (todas as telas passam por aqui).</summary>
    public sealed class Db
    {
        private readonly string _connectionString;

        public Db(string connectionString) => _connectionString = connectionString;

        /// <summary>Lê ConnectionStrings:HytechDb do appsettings.json ao lado do .exe. Vazio = modo demonstração.</summary>
        public static string LerConnectionString()
        {
            var caminho = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            if (!File.Exists(caminho)) return string.Empty;

            using var doc = JsonDocument.Parse(File.ReadAllText(caminho));
            if (doc.RootElement.TryGetProperty("ConnectionStrings", out var cs) &&
                cs.TryGetProperty("HytechDb", out var valor))
                return valor.GetString() ?? string.Empty;
            return string.Empty;
        }

        public static SqlParameter P(string nome, object? valor) => new(nome, valor ?? DBNull.Value);

        public List<T> Consultar<T>(string proc, Func<SqlDataReader, T> mapear, params SqlParameter[] ps)
            => Rodar(proc, ps, cmd =>
            {
                var lista = new List<T>();
                using var r = cmd.ExecuteReader();
                while (r.Read()) lista.Add(mapear(r));
                return lista;
            });

        public T Escalar<T>(string proc, params SqlParameter[] ps)
            => Rodar(proc, ps, cmd =>
            {
                var o = cmd.ExecuteScalar();
                return o is null || o is DBNull ? default(T) : (T)Convert.ChangeType(o, typeof(T));
            });

        public void Executar(string proc, params SqlParameter[] ps)
            => Rodar<object>(proc, ps, cmd => { cmd.ExecuteNonQuery(); return null; });

        private T Rodar<T>(string proc, SqlParameter[] ps, Func<SqlCommand, T> acao)
        {
            try
            {
                using var con = new SqlConnection(_connectionString);
                con.Open();
                using var cmd = new SqlCommand(proc, con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddRange(ps);
                return acao(cmd);
            }
            catch (SqlException ex) when (ex.Number == 50000)   // RAISERROR das procedures
            {
                throw new ServicoException(ex.Message, ex);
            }
            catch (SqlException ex)
            {
                throw new ServicoException("Erro ao acessar o banco de dados: " + ex.Message, ex);
            }
        }
    }

    /// <summary>Leitura segura de colunas (NULL vira vazio).</summary>
    public static class LeitorExtensoes
    {
        public static string Txt(this SqlDataReader r, string coluna)
        {
            var i = r.GetOrdinal(coluna);
            return r.IsDBNull(i) ? string.Empty : Convert.ToString(r.GetValue(i)) ?? string.Empty;
        }

        public static int Int(this SqlDataReader r, string coluna)
        {
            var i = r.GetOrdinal(coluna);
            return r.IsDBNull(i) ? 0 : Convert.ToInt32(r.GetValue(i));
        }

        public static string Data(this SqlDataReader r, string coluna, string formato = "dd/MM/yyyy")
        {
            var i = r.GetOrdinal(coluna);
            return r.IsDBNull(i) ? string.Empty : r.GetDateTime(i).ToString(formato);
        }

        public static DateTime DataHora(this SqlDataReader r, string coluna)
        {
            var i = r.GetOrdinal(coluna);
            return r.IsDBNull(i) ? DateTime.MinValue : r.GetDateTime(i);
        }
    }
}
