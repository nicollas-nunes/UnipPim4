namespace HytechAdmin.Security
{
    public interface ISenhaHasher
    {
        string Hash(string senha);
        bool Verificar(string senha, string hashArmazenado);
    }

    /// <summary>
    /// BCrypt (pacote BCrypt.Net-Next), o algoritmo citado no schema (Usuario.senha_hash).
    /// PRECISA ser o mesmo da API de login da plataforma: se ela usar outro algoritmo,
    /// troque apenas esta classe.
    /// </summary>
    public class SenhaHasherBcrypt : ISenhaHasher
    {
        public string Hash(string senha) => BCrypt.Net.BCrypt.HashPassword(senha);

        public bool Verificar(string senha, string hashArmazenado)
        {
            if (string.IsNullOrEmpty(hashArmazenado)) return false;
            try { return BCrypt.Net.BCrypt.Verify(senha, hashArmazenado); }
            catch (Exception) { return false; }   // hash em formato inválido = senha não confere
        }
    }
}
