using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Contrato do serviço de usuários usado pelas telas do Admin.
    /// Implementações: <see cref="UsuarioServiceSql"/> (banco real) e <see cref="UsuarioServiceMock"/> (demonstração).
    /// Erros de regra de negócio são lançados como <see cref="HytechAdmin.Data.ServicoException"/>.
    /// </summary>
    public interface IUsuarioService
    {
        List<Usuario> ObterTodos();
        Usuario? ObterPorId(int id);
        void Adicionar(Usuario usuario);
        void Atualizar(Usuario usuario);
        void Remover(int id);
        void AlternarStatus(int id);

        /// <summary>Especialidades possíveis do professor (títulos das matérias, com ícone: "💻 Programação").</summary>
        List<string> ObterEspecialidades();
    }
}
