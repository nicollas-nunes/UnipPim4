using HytechAdmin.Data;
using HytechAdmin.Models;
using static HytechAdmin.Data.Db;

namespace HytechAdmin.Services
{
    /// <summary>Configuração, métricas e logs via sp_ObterConfiguracaoPlataforma, sp_AtualizarConfiguracaoPlataforma, ...</summary>
    public class PlataformaServiceSql : IPlataformaService
    {
        private readonly Db _db;
        private readonly AdminLogado _admin;

        public PlataformaServiceSql(Db db, AdminLogado admin)
        {
            _db = db;
            _admin = admin;
        }

        public ConfiguracaoPlataforma ObterConfiguracao()
            => _db.Consultar("sp_ObterConfiguracaoPlataforma", r => new ConfiguracaoPlataforma
            {
                ChavesQuestaoFacil = r.Int("chaves_questao_facil"),
                ChavesQuestaoMedia = r.Int("chaves_questao_media"),
                ChavesQuestaoDificil = r.Int("chaves_questao_dificil"),
                ChavesCertificado = r.Int("chaves_certificado")
            }).FirstOrDefault() ?? new ConfiguracaoPlataforma();

        public void SalvarConfiguracao(ConfiguracaoPlataforma c)
            => _db.Executar("sp_AtualizarConfiguracaoPlataforma",
                P("@chaves_questao_facil", c.ChavesQuestaoFacil),
                P("@chaves_questao_media", c.ChavesQuestaoMedia),
                P("@chaves_questao_dificil", c.ChavesQuestaoDificil),
                P("@chaves_certificado", c.ChavesCertificado),
                P("@id_usuario_admin", _admin.IdUsuario));

        public MetricasPlataforma ObterMetricas()
            => _db.Consultar("sp_MetricasPlataforma", r => new MetricasPlataforma
            {
                TotalUsuarios = r.Int("total_usuarios"),
                UsuariosAtivos = r.Int("usuarios_ativos"),
                TotalAlunos = r.Int("total_alunos"),
                TotalProfessores = r.Int("total_professores"),
                TotalAdmins = r.Int("total_admins"),
                PendentesTotal = r.Int("pendentes_total"),
                CertificadosEmitidos = r.Int("certificados_emitidos"),
                ChavesDistribuidas = Convert.ToInt64(r.GetValue(r.GetOrdinal("chaves_distribuidas")))
            }).FirstOrDefault() ?? new MetricasPlataforma();

        public List<LogEntry> ObterLogs()
            => _db.Consultar("sp_ListarLogs", r => new LogEntry
            {
                Momento = r.DataHora("data_hora"),
                Mensagem = r.Txt("descricao")
            }, P("@top", 100));
    }
}
