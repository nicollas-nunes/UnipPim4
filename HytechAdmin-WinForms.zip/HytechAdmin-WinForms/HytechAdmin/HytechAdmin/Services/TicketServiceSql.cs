using HytechAdmin.Data;
using HytechAdmin.Models;
using static HytechAdmin.Data.Db;

namespace HytechAdmin.Services
{
    /// <summary>Tickets via sp_AdminListarTickets, sp_MensagensTicket, sp_ResponderTicket e sp_FecharTicket.</summary>
    public class TicketServiceSql : ITicketService
    {
        private readonly Db _db;
        private readonly AdminLogado _admin;

        public TicketServiceSql(Db db, AdminLogado admin)
        {
            _db = db;
            _admin = admin;
        }

        public List<TicketItem> ObterTickets(bool somenteMeus)
            => _db.Consultar("sp_AdminListarTickets", r =>
            {
                var idDest = r.Int("id_usuario_destinatario");
                return new TicketItem
                {
                    Id = r.Int("id_ticket"),
                    Assunto = r.Txt("assunto"),
                    Status = r.Txt("status"),
                    Materia = r.Txt("materia"),
                    Solicitante = r.Txt("solicitante"),
                    Destinatario = r.Txt("destinatario"),
                    IdDestinatario = idDest,
                    DataAbertura = r.Data("data_abertura", "dd/MM/yyyy HH:mm"),
                    UltimaMensagem = r.Data("ultima_mensagem", "dd/MM/yyyy HH:mm"),
                    TotalMensagens = r.Int("total_mensagens"),
                    AtribuidoAoAdmin = idDest == _admin.IdUsuario
                };
            },
            P("@id_usuario_admin", _admin.IdUsuario),
            P("@escopo", somenteMeus ? "meus" : "todos"));

        public List<TicketMensagemItem> ObterMensagens(int idTicket)
            => _db.Consultar("sp_MensagensTicket", r => new TicketMensagemItem
            {
                Id = r.Int("id_mensagem"),
                IdRemetente = r.Int("id_usuario_remetente"),
                Nome = r.Txt("nome"),
                Papel = r.Txt("papel"),
                Texto = r.Txt("texto"),
                DataHora = r.DataHora("data_hora")
            },
            P("@id_ticket", idTicket),
            P("@id_usuario", _admin.IdUsuario));

        public void Responder(int idTicket, string texto)
            => _db.Executar("sp_ResponderTicket",
                P("@id_ticket", idTicket),
                P("@id_usuario_remetente", _admin.IdUsuario),
                P("@texto", texto));

        public void Encerrar(int idTicket)
            => _db.Executar("sp_FecharTicket",
                P("@id_ticket", idTicket),
                P("@id_usuario", _admin.IdUsuario));
    }
}
