using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Implementação em memória, apenas para demonstração (sem banco).</summary>
    public class ConteudoServiceMock : IConteudoService
    {
        private readonly List<ConteudoItem> _conteudos;

        public ConteudoServiceMock()
        {
            _conteudos = new List<ConteudoItem>
            {
                Novo("aula:1", "texto",   "Introdução a Variáveis",       "Programação",    "Prof. Silva",    "aprovado", "10/04/2026", "", "Conteúdo introdutório sobre declaração, tipos e uso de variáveis."),
                Novo("aula:2", "texto",   "Estruturas de Repetição",      "Programação",    "Prof. Silva",    "aprovado", "12/04/2026", "", "Uso de laços for e while com exemplos práticos."),
                Novo("aula:3", "texto",   "Fundamentos de Design",        "Design",         "Prof. Ana Lima", "aprovado", "15/04/2026", "", "Princípios básicos de hierarquia visual, cor e tipografia."),
                Novo("aula:4", "texto",   "SQL Básico",                   "Banco de Dados", "Prof. Ana Lima", "aprovado", "18/04/2026", "", "Comandos SELECT, INSERT, UPDATE e DELETE."),
                Novo("questao:1", "questao", "O que é tipagem dinâmica?",     "Programação",    "Prof. Silva",    "aprovado", "20/04/2026", "Fácil", "Questão de múltipla escolha sobre tipagem dinâmica."),
                Novo("questao:2", "questao", "Explique o uso de JOIN em SQL", "Banco de Dados", "Prof. Ana Lima", "aprovado", "22/04/2026", "Médio", "Questão sobre os tipos de JOIN em SQL."),
                Novo("aula:5", "texto",   "Funções e Escopo",             "Programação",    "Prof. Silva",    "pendente", "02/05/2026", "", "Conteúdo sobre funções, escopo local e global."),
                Novo("desafio:1", "desafio", "Calculadora em Python",         "Programação",    "Prof. Silva",    "pendente", "03/05/2026", "Médio", "Implemente uma calculadora com as quatro operações."),
            };
        }

        private static ConteudoItem Novo(string id, string tipo, string titulo, string materia, string autor,
                                         string status, string data, string dificuldade, string corpo)
            => new()
            {
                Id = id, IdOrigem = int.Parse(id.Split(':')[1]), Tipo = tipo, Titulo = titulo, Materia = materia,
                Autor = autor, Status = status, Data = data, Dificuldade = dificuldade, Corpo = corpo
            };

        public List<ConteudoItem> ObterTodos() => _conteudos.ToList();

        public ConteudoItem? ObterPorId(string id) => _conteudos.FirstOrDefault(c => c.Id == id);

        public void Aprovar(string id) => Alterar(id, "aprovado");
        public void Rejeitar(string id) => Alterar(id, "rejeitado");

        public void Remover(string id) => _conteudos.RemoveAll(c => c.Id == id);

        private void Alterar(string id, string status)
        {
            var item = ObterPorId(id);
            if (item is not null) item.Status = status;
        }
    }
}
