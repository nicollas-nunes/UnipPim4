using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Contrato do serviço de configurações de gamificação, métricas e log do sistema.
    /// O log é gravado pelas próprias procedures do banco (LogAtividade); o app só lê.
    /// </summary>
    public interface IPlataformaService
    {
        ConfiguracaoPlataforma ObterConfiguracao();
        void SalvarConfiguracao(ConfiguracaoPlataforma configuracao);
        MetricasPlataforma ObterMetricas();
        List<LogEntry> ObterLogs();
    }
}
