using HytechAdmin.Data;
using HytechAdmin.Models;
using Microsoft.Data.SqlClient;
using static HytechAdmin.Data.Db;

namespace HytechAdmin.Services
{
    /// <summary>Aulas, questões e desafios via sp_AdminListarConteudos / sp_AdminObterConteudo / ...</summary>
    public class ConteudoServiceSql : IConteudoService
    {
        private readonly Db _db;
        private readonly AdminLogado _admin;

        public ConteudoServiceSql(Db db, AdminLogado admin)
        {
            _db = db;
            _admin = admin;
        }

        public List<ConteudoItem> ObterTodos() => _db.Consultar("sp_AdminListarConteudos", Mapear);

        public ConteudoItem? ObterPorId(string id)
        {
            var (tipo, idOrigem) = Separar(id);
            return _db.Consultar("sp_AdminObterConteudo", Mapear, P("@tipo", tipo), P("@id", idOrigem)).FirstOrDefault();
        }

        public void Aprovar(string id) => Decidir(id, "aprovado");
        public void Rejeitar(string id) => Decidir(id, "rejeitado");

        public void Remover(string id)
        {
            var (tipo, idOrigem) = Separar(id);
            _db.Executar("sp_AdminExcluirConteudo",
                P("@tipo", tipo), P("@id", idOrigem), P("@id_usuario_admin", _admin.IdUsuario));
        }

        private void Decidir(string id, string decisao)
        {
            var (tipo, idOrigem) = Separar(id);
            _db.Executar("sp_AdminDecidirConteudo",
                P("@tipo", tipo), P("@id", idOrigem), P("@decisao", decisao), P("@id_usuario_admin", _admin.IdUsuario));
        }

        private static (string tipo, int id) Separar(string idComposto)
        {
            var partes = idComposto.Split(':');
            if (partes.Length != 2 || !int.TryParse(partes[1], out var n))
                throw new ServicoException("Identificador de conteúdo inválido: " + idComposto);
            return (partes[0], n);
        }

        private static ConteudoItem Mapear(SqlDataReader r)
        {
            var tipoBanco = r.Txt("tipo");
            var id = r.Int("id");
            return new ConteudoItem
            {
                Id = ConteudoItem.MontarId(tipoBanco, id),
                IdOrigem = id,
                Tipo = tipoBanco == "aula" ? "texto" : tipoBanco,
                Titulo = r.Txt("titulo"),
                Materia = r.Txt("materia"),
                Autor = r.Txt("autor"),
                Status = r.Txt("status"),
                Data = r.Data("data"),
                Dificuldade = FormatarDificuldade(r.Txt("dificuldade")),
                Corpo = r.Txt("corpo")
            };
        }

        /// <summary>Aceita 'facil', 'Fácil', 'medio', 'difícil'... e devolve o texto de exibição.</summary>
        private static string FormatarDificuldade(string valor)
        {
            var chave = valor.Trim().ToLowerInvariant()
                .Replace('á', 'a').Replace('é', 'e').Replace('í', 'i');
            return chave switch
            {
                "facil" => "Fácil",
                "medio" => "Médio",
                "dificil" => "Difícil",
                _ => valor
            };
        }
    }
}
