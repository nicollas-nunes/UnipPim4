using HytechAdmin.Data;
using HytechAdmin.Models;
using HytechAdmin.Security;
using static HytechAdmin.Data.Db;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Login do Admin usando sp_ObterUsuarioParaLogin (a mesma da plataforma): só entra quem tem
    /// papel 'admin' e está ativo. O login é registrado em LogAtividade via sp_RegistrarLogin.
    /// </summary>
    public class AutenticacaoService
    {
        private readonly Db _db;
        private readonly ISenhaHasher _hasher;

        public AutenticacaoService(Db db, ISenhaHasher hasher)
        {
            _db = db;
            _hasher = hasher;
        }

        /// <summary>Retorna o admin autenticado ou null (mesma mensagem para qualquer falha, de propósito).</summary>
        public AdminLogado? Autenticar(string email, string senha)
        {
            var linha = _db.Consultar("sp_ObterUsuarioParaLogin", r => new
            {
                Id = r.Int("id_usuario"),
                Nome = r.Txt("nome"),
                Hash = r.Txt("senha_hash"),
                Status = r.Txt("status"),
                Papel = r.Txt("papel")
            }, P("@email", email.Trim())).FirstOrDefault();

            if (linha is null || linha.Papel != "admin" || linha.Status != "ativo" || !_hasher.Verificar(senha, linha.Hash))
                return null;

            _db.Executar("sp_RegistrarLogin", P("@id_usuario", linha.Id));
            return new AdminLogado { IdUsuario = linha.Id, Nome = linha.Nome };
        }
    }
}
