using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Tickets de suporte vistos pelo Admin. Quando nenhum professor tem a especialidade da matéria,
    /// o ticket é encaminhado a um administrador (ver sp_AbrirTicket).
    /// </summary>
    public interface ITicketService
    {
        /// <param name="somenteMeus">true = só os enviados ao admin logado; false = todos da plataforma.</param>
        List<TicketItem> ObterTickets(bool somenteMeus);
        List<TicketMensagemItem> ObterMensagens(int idTicket);
        void Responder(int idTicket, string texto);
        void Encerrar(int idTicket);
    }
}
