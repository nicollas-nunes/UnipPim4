using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Implementação em memória, apenas para demonstração (sem banco).</summary>
    public class TicketServiceMock : ITicketService
    {
        private readonly AdminLogado _admin;
        private readonly List<TicketItem> _tickets;
        private readonly Dictionary<int, List<TicketMensagemItem>> _mensagens = new();

        public TicketServiceMock(AdminLogado admin)
        {
            _admin = admin;
            _tickets = new List<TicketItem>
            {
                Novo(1, "Dúvida sobre JOIN", "aberto", "Banco de Dados", "Pedro Bala", admin.Nome, admin.IdUsuario, true),
                Novo(2, "Não consigo desbloquear a matéria", "respondido", "Design", "Maria Helena", admin.Nome, admin.IdUsuario, true),
                Novo(3, "Erro no exercício de laços", "aberto", "Programação", "Álvaro de Campos", "Prof. Silva", 99, false),
            };
            Mensagem(1, 201, "Pedro Bala", "aluno", "Não entendi a diferença entre INNER JOIN e LEFT JOIN.");
            Mensagem(2, 202, "Maria Helena", "aluno", "Tenho chaves suficientes mas o botão não libera.");
            Mensagem(2, _admin.IdUsuario, admin.Nome, "admin", "Conclua a matéria anterior para liberar esta.");
            Mensagem(3, 203, "Álvaro de Campos", "aluno", "O exercício 3 não aceita minha resposta.");
        }

        private static TicketItem Novo(int id, string assunto, string status, string materia, string solicitante,
                                       string destinatario, int idDest, bool meu)
            => new()
            {
                Id = id, Assunto = assunto, Status = status, Materia = materia, Solicitante = solicitante,
                Destinatario = destinatario, IdDestinatario = idDest, AtribuidoAoAdmin = meu,
                DataAbertura = DateTime.Now.AddDays(-id).ToString("dd/MM/yyyy HH:mm")
            };

        private void Mensagem(int idTicket, int idRemetente, string nome, string papel, string texto)
        {
            if (!_mensagens.TryGetValue(idTicket, out var lista)) _mensagens[idTicket] = lista = new();
            lista.Add(new TicketMensagemItem
            {
                Id = lista.Count + 1, IdRemetente = idRemetente, Nome = nome, Papel = papel, Texto = texto,
                DataHora = DateTime.Now.AddMinutes(-60 * (10 - lista.Count))
            });
            var t = _tickets.First(x => x.Id == idTicket);
            t.TotalMensagens = lista.Count;
            t.UltimaMensagem = lista[^1].DataHora.ToString("dd/MM/yyyy HH:mm");
        }

        public List<TicketItem> ObterTickets(bool somenteMeus)
            => _tickets.Where(t => !somenteMeus || t.AtribuidoAoAdmin).ToList();

        public List<TicketMensagemItem> ObterMensagens(int idTicket)
            => _mensagens.TryGetValue(idTicket, out var l) ? l.ToList() : new List<TicketMensagemItem>();

        public void Responder(int idTicket, string texto)
        {
            var t = _tickets.First(x => x.Id == idTicket);
            if (t.EstaFechado) throw new HytechAdmin.Data.ServicoException("Ticket encerrado: não aceita novas mensagens.");
            Mensagem(idTicket, _admin.IdUsuario, _admin.Nome, "admin", texto);
            t.Status = "respondido";
        }

        public void Encerrar(int idTicket) => _tickets.First(x => x.Id == idTicket).Status = "fechado";
    }
}
