using HytechAdmin.Data;
using HytechAdmin.Models;
using HytechAdmin.Security;
using Microsoft.Data.SqlClient;
using static HytechAdmin.Data.Db;

namespace HytechAdmin.Services
{
    /// <summary>Usuários via stored procedures (sp_ListarUsuarios, sp_AdminSalvarUsuario, ...).</summary>
    public class UsuarioServiceSql : IUsuarioService
    {
        private readonly Db _db;
        private readonly ISenhaHasher _hasher;
        private readonly AdminLogado _admin;

        public UsuarioServiceSql(Db db, ISenhaHasher hasher, AdminLogado admin)
        {
            _db = db;
            _hasher = hasher;
            _admin = admin;
        }

        public List<Usuario> ObterTodos() => _db.Consultar("sp_ListarUsuarios", Mapear);

        public Usuario? ObterPorId(int id) => ObterTodos().FirstOrDefault(u => u.Id == id);

        public void Adicionar(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Senha))
                throw new ServicoException("Defina uma senha para o novo usuário.");

            usuario.Id = _db.Escalar<int>("sp_AdminSalvarUsuario",
                P("@id_usuario", null),
                P("@nome", usuario.Nome),
                P("@email", usuario.Email),
                P("@perfil", PerfilParaBanco(usuario.Perfil)),
                P("@especialidade", usuario.EhProfessor ? usuario.Especialidade : null),
                P("@senha_hash", _hasher.Hash(usuario.Senha)),
                P("@status", usuario.Status),
                P("@id_usuario_admin", _admin.IdUsuario));
        }

        public void Atualizar(Usuario usuario)
        {
            _db.Executar("sp_AdminSalvarUsuario",
                P("@id_usuario", usuario.Id),
                P("@nome", usuario.Nome),
                P("@email", usuario.Email),
                P("@perfil", PerfilParaBanco(usuario.Perfil)),
                P("@especialidade", usuario.EhProfessor ? usuario.Especialidade : null),
                // senha em branco = mantém a atual
                P("@senha_hash", string.IsNullOrWhiteSpace(usuario.Senha) ? null : _hasher.Hash(usuario.Senha)),
                P("@status", usuario.Status),
                P("@id_usuario_admin", _admin.IdUsuario));
        }

        public void Remover(int id)
            => _db.Executar("sp_ExcluirUsuario", P("@id_usuario", id), P("@id_usuario_admin", _admin.IdUsuario));

        public void AlternarStatus(int id)
        {
            var usuario = ObterPorId(id) ?? throw new ServicoException("Usuário não encontrado.");
            var novo = usuario.EhAtivo ? "inativo" : "ativo";
            _db.Executar("sp_AlterarStatusUsuario", P("@id_usuario", id), P("@novo_status", novo));
        }

        public List<string> ObterEspecialidades()
            => _db.Consultar("sp_ListarMaterias", r =>
            {
                var icone = r.Txt("icone").Trim();
                var titulo = r.Txt("titulo");
                return icone.Length > 0 ? $"{icone} {titulo}" : titulo;
            });

        private static Usuario Mapear(SqlDataReader r) => new()
        {
            Id = r.Int("id_usuario"),
            Nome = r.Txt("nome"),
            Nickname = r.Txt("nickname"),
            Email = r.Txt("email"),
            Perfil = PerfilDoBanco(r.Txt("perfil")),
            Especialidade = r.Txt("especialidade"),
            Status = r.Txt("status"),
            Cadastro = r.Data("data_cadastro")
        };

        // O banco chama o papel de 'admin'; a interface do app, de 'administrador'.
        private static string PerfilParaBanco(string perfil) => perfil == "administrador" ? "admin" : perfil;
        private static string PerfilDoBanco(string perfil) => perfil == "admin" ? "administrador" : perfil;
    }
}
