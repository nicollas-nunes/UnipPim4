using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Contrato do serviço de conteúdos (textos, questões e desafios) usado pelo Admin.
    /// </summary>
    public interface IConteudoService
    {
        List<ConteudoItem> ObterTodos();
        ConteudoItem? ObterPorId(string id);
        void Aprovar(string id);
        void Rejeitar(string id);
        void Remover(string id);
    }
}
