using HytechAdmin.Data;

namespace HytechAdmin.UI
{
    /// <summary>Exibição padronizada de erros vindos dos serviços.</summary>
    public static class Mensagens
    {
        public static void Erro(IWin32Window? dono, Exception ex)
        {
            // ServicoException = regra de negócio do banco (mensagem já é amigável)
            var icone = ex is ServicoException ? MessageBoxIcon.Warning : MessageBoxIcon.Error;
            MessageBox.Show(dono, ex.Message, "Atenção", MessageBoxButtons.OK, icone);
        }
    }
}
