namespace HytechAdmin.Models
{
    /// <summary>
    /// Conteúdo publicado na plataforma: texto explicativo (tabela Aula), questão (Questao) ou desafio (Desafio).
    /// Os três têm ids independentes no banco, então o Id do app é composto: "aula:12", "questao:7", "desafio:3".
    /// </summary>
    public class ConteudoItem
    {
        /// <summary>Chave composta "tipoBanco:idOrigem" (usada nas linhas do grid).</summary>
        public string Id { get; set; } = string.Empty;

        /// <summary>Id na tabela de origem (Aula / Questao / Desafio).</summary>
        public int IdOrigem { get; set; }

        /// <summary>texto | questao | desafio  ("texto" = Aula)</summary>
        public string Tipo { get; set; } = "texto";

        public string Titulo { get; set; } = string.Empty;
        public string Materia { get; set; } = string.Empty;
        public string Autor { get; set; } = string.Empty;

        /// <summary>aprovado | pendente | rejeitado  (rascunho é privado do professor e não aparece ao Admin)</summary>
        public string Status { get; set; } = "pendente";

        public string Data { get; set; } = string.Empty;

        /// <summary>Fácil | Médio | Difícil — questões e desafios.</summary>
        public string Dificuldade { get; set; } = string.Empty;

        /// <summary>Corpo completo, exibido na tela de visualização.</summary>
        public string Corpo { get; set; } = string.Empty;

        public bool EhQuestao => Tipo == "questao";
        public bool EhDesafio => Tipo == "desafio";
        public bool TemDificuldade => EhQuestao || EhDesafio;

        /// <summary>Nome do tipo no banco ('aula' | 'questao' | 'desafio').</summary>
        public string TipoBanco => Tipo == "texto" ? "aula" : Tipo;

        public static string MontarId(string tipoBanco, int id) => $"{tipoBanco}:{id}";
    }
}
