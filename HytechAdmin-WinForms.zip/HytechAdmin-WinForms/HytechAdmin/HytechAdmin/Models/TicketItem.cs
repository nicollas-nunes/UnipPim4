namespace HytechAdmin.Models
{
    /// <summary>Ticket de suporte (tabela TicketSuporte) enviado por um aluno a um professor ou ao admin.</summary>
    public class TicketItem
    {
        public int Id { get; set; }
        public string Assunto { get; set; } = string.Empty;

        /// <summary>aberto | respondido | fechado</summary>
        public string Status { get; set; } = "aberto";

        public string Materia { get; set; } = string.Empty;
        public string Solicitante { get; set; } = string.Empty;
        public string Destinatario { get; set; } = string.Empty;
        public int IdDestinatario { get; set; }
        public string DataAbertura { get; set; } = string.Empty;
        public string UltimaMensagem { get; set; } = string.Empty;
        public int TotalMensagens { get; set; }

        /// <summary>True quando o ticket foi enviado ao admin logado (ex.: nenhum professor da matéria).</summary>
        public bool AtribuidoAoAdmin { get; set; }

        public bool EstaFechado => Status == "fechado";
    }

    /// <summary>Mensagem de um ticket (tabela TicketMensagem).</summary>
    public class TicketMensagemItem
    {
        public int Id { get; set; }
        public int IdRemetente { get; set; }
        public string Nome { get; set; } = string.Empty;

        /// <summary>aluno | professor | admin</summary>
        public string Papel { get; set; } = string.Empty;

        public string Texto { get; set; } = string.Empty;
        public DateTime DataHora { get; set; }
    }
}
