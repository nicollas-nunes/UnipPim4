namespace HytechAdmin.Models
{
    /// <summary>Administrador autenticado na sessão (id_usuario é gravado nos logs e nas aprovações).</summary>
    public class AdminLogado
    {
        public int IdUsuario { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
