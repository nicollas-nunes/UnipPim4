namespace HytechAdmin.Models
{
    /// <summary>
    /// Usuário da plataforma. Mapeia a tabela Usuario + o papel (Aluno / Professor / Admin).
    /// No app o perfil é "aluno | professor | administrador"; no banco o papel Admin é 'admin'
    /// (a conversão é feita em UsuarioServiceSql).
    /// </summary>
    public class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Nickname { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        /// <summary>Texto puro, só usado ao criar o usuário ou redefinir a senha. Nunca é lido do banco.</summary>
        public string Senha { get; set; } = string.Empty;

        /// <summary>aluno | professor | administrador</summary>
        public string Perfil { get; set; } = "aluno";

        /// <summary>Só é relevante quando Perfil == "professor". Igual ao título de uma Materia.</summary>
        public string Especialidade { get; set; } = string.Empty;

        /// <summary>ativo | inativo</summary>
        public string Status { get; set; } = "ativo";

        public string Cadastro { get; set; } = string.Empty;

        public bool EhProfessor => Perfil == "professor";
        public bool EhAtivo => Status == "ativo";
    }
}
