namespace HytechAdmin.Models
{
    /// <summary>Resultado de sp_MetricasPlataforma (aba Plataforma).</summary>
    public class MetricasPlataforma
    {
        public int TotalUsuarios { get; set; }
        public int UsuariosAtivos { get; set; }
        public int TotalAlunos { get; set; }
        public int TotalProfessores { get; set; }
        public int TotalAdmins { get; set; }
        public int PendentesTotal { get; set; }
        public int CertificadosEmitidos { get; set; }
        public long ChavesDistribuidas { get; set; }
    }
}
