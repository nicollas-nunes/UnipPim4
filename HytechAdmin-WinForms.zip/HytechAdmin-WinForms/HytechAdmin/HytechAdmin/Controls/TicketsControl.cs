using HytechAdmin.Forms;
using HytechAdmin.Models;
using HytechAdmin.Services;
using HytechAdmin.UI;

namespace HytechAdmin.Controls
{
    /// <summary>Tela "Tickets": lista, filtra, abre a conversa, responde e encerra tickets de suporte.</summary>
    public class TicketsControl : UserControl
    {
        private readonly ITicketService _servico;
        private List<TicketItem> _tickets = new();

        private TextBox _txtBusca = null!;
        private ComboBox _cmbEscopo = null!;
        private ComboBox _cmbStatus = null!;
        private DataGridView _grid = null!;
        private Label _lblVazio = null!;

        public TicketsControl(ITicketService servico)
        {
            _servico = servico;
            Dock = DockStyle.Fill;
            MontarLayout();
            Recarregar();
        }

        private void MontarLayout()
        {
            var raiz = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Theme.CinzaFundo
            };
            raiz.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            raiz.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(raiz);

            var painelTopo = new Panel { Dock = DockStyle.Top, Height = 30, Margin = new Padding(0, 0, 0, 8) };
            var subtitulo = Theme.CriarSubtitulo(
                "Tickets enviados ao administrador (quando nenhum professor atende a matéria). Use \"Todos\" para acompanhar a plataforma.");
            subtitulo.Location = new Point(0, 0);
            painelTopo.Controls.Add(subtitulo);
            raiz.Controls.Add(painelTopo, 0, 0);

            var painelFiltros = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0, 4, 0, 12)
            };

            _txtBusca = Theme.CriarCampoTexto();
            _txtBusca.Width = 240;
            _txtBusca.PlaceholderText = "🔍 Buscar por assunto ou aluno...";
            _txtBusca.TextChanged += (_, _) => AplicarFiltros();
            painelFiltros.Controls.Add(EnvolverComMargem(_txtBusca));

            _cmbEscopo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 180, Font = Theme.FonteBase };
            _cmbEscopo.Items.AddRange(new object[] { "Atribuídos a mim", "Todos os tickets" });
            _cmbEscopo.SelectedIndex = 0;
            _cmbEscopo.SelectedIndexChanged += (_, _) => Recarregar();   // muda a consulta ao banco
            painelFiltros.Controls.Add(EnvolverComMargem(_cmbEscopo));

            _cmbStatus = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 150, Font = Theme.FonteBase };
            _cmbStatus.Items.AddRange(new object[] { "Todos os Status", "Aberto", "Respondido", "Encerrado" });
            _cmbStatus.SelectedIndex = 0;
            _cmbStatus.SelectedIndexChanged += (_, _) => AplicarFiltros();
            painelFiltros.Controls.Add(EnvolverComMargem(_cmbStatus));

            raiz.Controls.Add(painelFiltros, 0, 1);

            var painelGrid = new Panel { Dock = DockStyle.Fill };
            _grid = Theme.CriarGridPadrao();
            _grid.AutoGenerateColumns = false;
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Assunto", HeaderText = "Assunto", FillWeight = 22 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Solicitante", HeaderText = "Aluno", FillWeight = 13 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Destinatario", HeaderText = "Para", FillWeight = 13 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Materia", HeaderText = "Matéria", FillWeight = 12 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Status", HeaderText = "Status", FillWeight = 11 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Abertura", HeaderText = "Abertura", FillWeight = 12 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Ultima", HeaderText = "Última mensagem", FillWeight = 12 });
            _grid.Columns.Add(new DataGridViewButtonColumn { Name = "AcaoAbrir", HeaderText = "", Text = "💬 Abrir", UseColumnTextForButtonValue = true, FillWeight = 8 });
            _grid.CellContentClick += Grid_CellContentClick;
            painelGrid.Controls.Add(_grid);

            _lblVazio = new Label
            {
                Text = "🎫  Nenhum ticket encontrado com os filtros selecionados.",
                Font = Theme.FonteBase,
                ForeColor = Theme.CinzaTexto,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                Visible = false
            };
            painelGrid.Controls.Add(_lblVazio);
            _lblVazio.BringToFront();

            raiz.Controls.Add(painelGrid, 0, 2);
        }

        private static Control EnvolverComMargem(Control controle)
        {
            var painel = new Panel { AutoSize = true, Margin = new Padding(0, 0, 10, 0) };
            controle.Location = Point.Empty;
            painel.Controls.Add(controle);
            painel.Height = controle.Height;
            painel.Width = controle.Width;
            return painel;
        }

        /// <summary>Busca no serviço (banco) conforme o escopo e reaplica os filtros.</summary>
        private void Recarregar()
        {
            try { _tickets = _servico.ObterTickets(somenteMeus: _cmbEscopo.SelectedIndex == 0); }
            catch (Exception ex) { _tickets = new List<TicketItem>(); Mensagens.Erro(null, ex); }
            AplicarFiltros();
        }

        private void AplicarFiltros()
        {
            var busca = _txtBusca.Text.Trim().ToLower();
            var statusFiltro = _cmbStatus.SelectedIndex switch
            {
                1 => "aberto",
                2 => "respondido",
                3 => "fechado",
                _ => ""
            };

            var lista = _tickets
                .Where(t => string.IsNullOrEmpty(busca) || t.Assunto.ToLower().Contains(busca) || t.Solicitante.ToLower().Contains(busca))
                .Where(t => string.IsNullOrEmpty(statusFiltro) || t.Status == statusFiltro)
                .ToList();

            _grid.Rows.Clear();
            foreach (var t in lista)
            {
                int idx = _grid.Rows.Add(
                    t.Assunto,
                    t.Solicitante,
                    t.AtribuidoAoAdmin ? "🛡️ Você" : t.Destinatario,
                    string.IsNullOrEmpty(t.Materia) ? "—" : t.Materia,
                    FormatarStatus(t.Status),
                    t.DataAbertura,
                    string.IsNullOrEmpty(t.UltimaMensagem) ? "—" : t.UltimaMensagem,
                    "💬 Abrir");
                _grid.Rows[idx].Tag = t.Id;
            }

            _lblVazio.Visible = lista.Count == 0;
            _grid.Visible = lista.Count > 0;
        }

        private static string FormatarStatus(string status) => status switch
        {
            "aberto" => "🔴 Aberto",
            "respondido" => "🟢 Respondido",
            "fechado" => "⚫ Encerrado",
            _ => status
        };

        private void Grid_CellContentClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (_grid.Columns[e.ColumnIndex].Name != "AcaoAbrir") return;
            if (_grid.Rows[e.RowIndex].Tag is not int id) return;

            var ticket = _tickets.FirstOrDefault(t => t.Id == id);
            if (ticket is null) return;

            using var form = new TicketForm(_servico, ticket);
            form.ShowDialog(this);
            if (form.Alterou) Recarregar();
        }
    }
}
