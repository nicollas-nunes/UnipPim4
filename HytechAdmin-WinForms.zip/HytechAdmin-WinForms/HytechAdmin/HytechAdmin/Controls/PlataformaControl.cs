using HytechAdmin.Models;
using HytechAdmin.Services;
using HytechAdmin.UI;

namespace HytechAdmin.Controls
{
    /// <summary>Tela "Plataforma": métricas gerais, distribuição de perfis e log do sistema.</summary>
    public class PlataformaControl : UserControl
    {
        private readonly IPlataformaService _plataformaService;

        private FlowLayoutPanel _painelCards = null!;
        private Panel _painelDistribuicao = null!;
        private ListBox _listaLog = null!;

        public PlataformaControl(IPlataformaService plataformaService)
        {
            _plataformaService = plataformaService;
            Dock = DockStyle.Fill;
            MontarLayout();
            AtualizarDados();
        }

        private void MontarLayout()
        {
            var raiz = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4
            };
            raiz.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            raiz.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            raiz.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(raiz);

            var subtitulo = Theme.CriarSubtitulo("Visão geral do uso da plataforma e histórico de atividades recentes.");
            raiz.Controls.Add(subtitulo, 0, 0);

            _painelCards = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0, 0, 0, 20)
            };
            raiz.Controls.Add(_painelCards, 0, 1);

            _painelDistribuicao = new Panel
            {
                BackColor = Theme.Branco,
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(560, 190),
                Margin = new Padding(0, 0, 0, 20),
                Padding = new Padding(20)
            };
            raiz.Controls.Add(_painelDistribuicao, 0, 2);

            var painelLog = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Branco,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(20)
            };
            var lblLogTitulo = new Label
            {
                Text = "🗒️ Log do Sistema",
                Font = Theme.FonteBaseNegrito,
                ForeColor = Theme.RoxoEscuro,
                AutoSize = true,
                Dock = DockStyle.Top
            };
            painelLog.Controls.Add(lblLogTitulo);

            _listaLog = new ListBox
            {
                Dock = DockStyle.Fill,
                Font = Theme.FonteMono,
                BorderStyle = BorderStyle.None,
                BackColor = Theme.CinzaFundo,
                IntegralHeight = false,
                Margin = new Padding(0, 8, 0, 0)
            };
            painelLog.Controls.Add(_listaLog);
            _listaLog.BringToFront();

            raiz.Controls.Add(painelLog, 0, 3);
        }

        private void AtualizarDados()
        {
            MetricasPlataforma m;
            List<LogEntry> logs;
            try
            {
                m = _plataformaService.ObterMetricas();
                logs = _plataformaService.ObterLogs();
            }
            catch (Exception ex)
            {
                Mensagens.Erro(null, ex);
                m = new MetricasPlataforma();
                logs = new List<LogEntry>();
            }

            double taxaRetencao = m.TotalUsuarios == 0 ? 0 : (double)m.UsuariosAtivos / m.TotalUsuarios * 100;

            // Cards de métricas (todos vindos de sp_MetricasPlataforma)
            _painelCards.Controls.Clear();
            _painelCards.Controls.Add(CriarCard("👤", "Total de Usuários", m.TotalUsuarios.ToString(), Theme.RoxoEscuro));
            _painelCards.Controls.Add(CriarCard("🔑", "Chaves Distribuídas", m.ChavesDistribuidas.ToString("N0"), Theme.Laranja));
            _painelCards.Controls.Add(CriarCard("🎓", "Certificados Emitidos", m.CertificadosEmitidos.ToString(), Theme.Verde));
            _painelCards.Controls.Add(CriarCard("📈", "Taxa de Retenção", $"{taxaRetencao:0.#}%", Theme.RoxoMedio));
            _painelCards.Controls.Add(CriarCard("🕓", "Aguardando Aprovação", m.PendentesTotal.ToString(), Theme.Amarelo));

            // Distribuição de perfis
            _painelDistribuicao.Controls.Clear();
            _painelDistribuicao.Controls.Add(new Label
            {
                Text = "👥 Distribuição de Usuários",
                Font = Theme.FonteBaseNegrito,
                ForeColor = Theme.RoxoEscuro,
                AutoSize = true,
                Location = new Point(0, 0)
            });

            int y = 32;
            AdicionarBarraDistribuicao(_painelDistribuicao, "🎓 Alunos", m.TotalAlunos, m.TotalUsuarios, Theme.RoxoMedio, ref y);
            AdicionarBarraDistribuicao(_painelDistribuicao, "👨‍🏫 Professores", m.TotalProfessores, m.TotalUsuarios, Theme.Amarelo, ref y);
            AdicionarBarraDistribuicao(_painelDistribuicao, "🛡️ Administradores", m.TotalAdmins, m.TotalUsuarios, Theme.Verde, ref y);

            // Log (gravado pelas procedures em LogAtividade)
            _listaLog.Items.Clear();
            foreach (var log in logs)
                _listaLog.Items.Add($"{log.HoraFormatada}  {log.Mensagem}");
        }

        private static Panel CriarCard(string icone, string titulo, string valor, Color corDestaque)
        {
            var card = new Panel
            {
                BackColor = Theme.Branco,
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(210, 100),
                Margin = new Padding(0, 0, 16, 16),
                Padding = new Padding(16)
            };

            var barraCor = new Panel { BackColor = corDestaque, Dock = DockStyle.Left, Width = 4 };
            card.Controls.Add(barraCor);

            var lblIcone = new Label
            {
                Text = icone,
                Font = new Font("Segoe UI", 16F),
                AutoSize = true,
                Location = new Point(16, 12)
            };
            card.Controls.Add(lblIcone);

            var lblValor = new Label
            {
                Text = valor,
                Font = Theme.FonteMetrica,
                ForeColor = Theme.Preto,
                AutoSize = true,
                Location = new Point(16, 40)
            };
            card.Controls.Add(lblValor);

            var lblTitulo = new Label
            {
                Text = titulo,
                Font = Theme.FonteSubtitulo,
                ForeColor = Theme.CinzaTexto,
                AutoSize = true,
                Location = new Point(16, 76)
            };
            card.Controls.Add(lblTitulo);

            return card;
        }

        private static void AdicionarBarraDistribuicao(Panel container, string rotulo, int quantidade, int total, Color cor, ref int y)
        {
            double percentual = total == 0 ? 0 : (double)quantidade / total * 100;

            var lbl = new Label
            {
                Text = $"{rotulo}  ({quantidade} · {percentual:0.#}%)",
                Font = Theme.FonteBase,
                ForeColor = Theme.Preto,
                AutoSize = true,
                Location = new Point(0, y)
            };
            container.Controls.Add(lbl);
            y += 20;

            var trilha = new Panel
            {
                BackColor = Theme.CinzaFundo,
                Location = new Point(0, y),
                Size = new Size(500, 12)
            };
            var preenchido = new Panel
            {
                BackColor = cor,
                Location = new Point(0, 0),
                Size = new Size((int)(500 * percentual / 100), 12)
            };
            trilha.Controls.Add(preenchido);
            container.Controls.Add(trilha);
            y += 22;
        }
    }
}
