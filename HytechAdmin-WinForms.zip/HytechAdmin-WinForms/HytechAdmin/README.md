# HYTECH Admin — Painel Desktop (Windows Forms)

Base desktop em **C# / Windows Forms (.NET 8)**, focada **exclusivamente no Admin**,
construída a partir da identidade visual e das funcionalidades administrativas do
HTML de referência (`Interface_Hytech_18V`).

## Telas implementadas

| Tela | Descrição |
|---|---|
| **Login** | Só entra quem está na tabela `Admin` e está ativo (`sp_AdminAutenticar`). |
| **Gerenciar Usuários** | Listagem com busca e filtros (perfil/status), criar, editar (inclui senha e status), ativar/inativar e excluir (só sem histórico). |
| **Gerenciar Conteúdos** | Textos (Aula), questões e desafios: filtros, visualização, **aprovar / rejeitar** e remover. Rascunhos dos professores não aparecem. |
| **Tickets** | Tickets de suporte enviados ao admin (fallback quando nenhum professor tem a especialidade da matéria) ou de toda a plataforma: ver conversa, responder e encerrar. |
| **Config** | Chaves por questão fácil/média/difícil e por certificado (`ChavesConfig`). |
| **Plataforma** | Métricas reais (`sp_MetricasPlataforma`), distribuição de perfis e log (`LogAtividade`). |

## Estrutura do projeto

```
HytechAdmin/
├── HytechAdmin.sln
└── HytechAdmin/
    ├── Program.cs                  # Entry point (login + escolha banco/demonstração)
    ├── appsettings.json            # Connection string
    ├── Forms/                      # MainForm, LoginForm, UsuarioEditForm, ConteudoViewForm
    ├── Controls/                   # Usuários, Conteúdos, Tickets, Config, Plataforma
    ├── Models/                     # Usuario, ConteudoItem, TicketItem, LogEntry, ConfiguracaoPlataforma, MetricasPlataforma, AdminLogado
    ├── Data/Db.cs                  # Acesso ao SQL Server (stored procedures)
    ├── Security/SenhaHasher.cs     # Hash/verificação de senha
    ├── Services/                   # I*Service + *ServiceSql (banco) + *ServiceMock (demonstração)
    └── UI/                         # Theme e Mensagens
```

## Como abrir e rodar

1. Requer **Visual Studio 2022** (ou superior) com a carga de trabalho
   **".NET desktop development"**, e o **.NET 8 SDK**.
2. Abra `HytechAdmin.sln` (ou a pasta do projeto) no Visual Studio.
3. Defina `HytechAdmin` como projeto de inicialização e pressione **F5**.

> O projeto usa apenas o SDK do .NET (não depende de designer `.Designer.cs`);
> todas as telas são montadas em código, o que facilita revisão e versionamento.

## Banco de dados

1. Rode **somente** `HytechDB.sql` (script único e idempotente: cria o banco do zero ou migra um banco
   v3/v4/v5 existente). Para evoluir o banco, edite esse arquivo e rode de novo.
2. Edite `appsettings.json` (ao lado do `.exe`):

```json
{ "ConnectionStrings": { "HytechDb": "Server=localhost;Database=HytechDB;Trusted_Connection=True;TrustServerCertificate=True" } }
```

- **Com connection string**: tela de login e dados reais via stored procedures.
- **Em branco**: modo demonstração (mocks em memória, sem login).

Procedures usadas pelo app: `sp_ObterUsuarioParaLogin` / `sp_RegistrarLogin` (login do admin), `sp_ListarUsuarios`,
`sp_AdminSalvarUsuario`, `sp_AlterarStatusUsuario`, `sp_ExcluirUsuario`, `sp_ListarMaterias`,
`sp_AdminListarConteudos`, `sp_AdminObterConteudo`, `sp_AdminDecidirConteudo`, `sp_AdminExcluirConteudo`,
`sp_AdminListarTickets`, `sp_MensagensTicket`, `sp_ResponderTicket`, `sp_FecharTicket`,
`sp_ObterConfiguracaoPlataforma`, `sp_AtualizarConfiguracaoPlataforma`, `sp_MetricasPlataforma`, `sp_ListarLogs`.
Os logs são gravados pelo banco (procedures e triggers); o app só lê `LogAtividade`.

### Senhas
`Security/SenhaHasher.cs` usa **BCrypt** (`BCrypt.Net-Next`). Precisa ser o mesmo algoritmo da API de login
da plataforma; se for outro, troque apenas a classe `SenhaHasherBcrypt`.

## Observações de design

- Todas as cores e fontes ficam centralizadas em `UI/Theme.cs`, facilitando ajustes
  finos de identidade visual sem precisar caçar valores espalhados pelo código.
- Os dados de exemplo nos serviços mock replicam os mesmos usuários/conteúdos
  usados no protótipo HTML, para facilitar a comparação visual/funcional.
