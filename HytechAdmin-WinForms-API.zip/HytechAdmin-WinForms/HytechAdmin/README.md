# HYTECH Admin (WinForms, .NET 8)

Aplicativo desktop do administrador. **Não acessa mais o banco de dados**: toda comunicação passa pela
**HytechApi** (HTTP + JWT). O app não tem connection string, não usa SqlClient e não conhece o algoritmo de hash de senha.

## Modos de execução

Definido em `appsettings.json` (fica ao lado do `.exe`):

```json
{ "Api": { "BaseUrl": "https://sua-api.exemplo.com" } }
```

- **BaseUrl preenchida** → modo real: tela de login (só entra quem tem papel `admin` e conta ativa).
- **BaseUrl vazia** → modo demonstração, com dados em memória e sem login.

A API precisa usar **HTTPS**. `http://` só é aceito para `localhost`/`127.0.0.1` (desenvolvimento), porque a senha do
admin trafega nessa conexão.

## Como roda

```
Login (POST /auth/login-admin) → recebe JWT → ApiClient envia "Authorization: Bearer ..." em todas as chamadas
```

O token dura 120 minutos (configurável na API). Quando expira, o app mostra "Sessão expirada" e é preciso entrar de novo.

## Estrutura

```
Data/       ApiClient (HttpClient síncrono), ApiConfig (lê o appsettings), ServicoException
Services/   I*Service (contratos)  →  *ServiceApi (HytechApi)  e  *ServiceMock (demonstração)
Models/     modelos usados pelas telas
Forms/ Controls/ UI/   interface (não mudou)
```

As telas só conhecem as interfaces `I*Service`; trocar a origem dos dados foi só escrever as implementações `*ServiceApi`
e ajustar o `Program.cs`.

## Observações

- As chamadas são síncronas (como eram com o SQL) e têm timeout de 15 s: se a API estiver fora do ar, a tela espera até
  esse limite e mostra "Não foi possível conectar à API". Migrar para `async/await` é uma melhoria futura.
- O id do administrador **não é enviado pelo app**: a API o lê do token.
- O primeiro administrador é criado no banco (veja `HytechApi/sql/seed_admin.sql`).
