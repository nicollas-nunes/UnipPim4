using System.Text.Json;

namespace HytechAdmin.Data
{
    /// <summary>Lê o endereço da API do appsettings.json (ao lado do .exe). Vazio = modo demonstração.</summary>
    public static class ApiConfig
    {
        public static string LerBaseUrl()
        {
            var caminho = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            if (!File.Exists(caminho)) return string.Empty;

            using var doc = JsonDocument.Parse(File.ReadAllText(caminho));
            if (doc.RootElement.TryGetProperty("Api", out var api) &&
                api.TryGetProperty("BaseUrl", out var valor))
                return (valor.GetString() ?? string.Empty).Trim();
            return string.Empty;
        }

        /// <summary>
        /// A senha do admin trafega nesta conexão: só aceita HTTPS (ou HTTP em localhost, para desenvolvimento).
        /// </summary>
        public static void Validar(string baseUrl)
        {
            if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var uri))
                throw new ServicoException("Api:BaseUrl no appsettings.json não é um endereço válido.");

            var local = uri.IsLoopback;
            if (uri.Scheme != Uri.UriSchemeHttps && !(uri.Scheme == Uri.UriSchemeHttp && local))
                throw new ServicoException(
                    "A API precisa usar HTTPS (HTTP só é aceito em localhost). Corrija Api:BaseUrl no appsettings.json.");
        }
    }
}
