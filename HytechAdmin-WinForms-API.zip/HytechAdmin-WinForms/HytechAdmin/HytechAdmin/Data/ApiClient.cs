using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace HytechAdmin.Data
{
    /// <summary>
    /// Cliente HTTP da HytechApi. As telas do app são síncronas, então usa HttpClient.Send (síncrono,
    /// sem risco de deadlock na thread de UI). Erros viram <see cref="ServicoException"/>.
    /// </summary>
    public sealed class ApiClient : IDisposable
    {
        private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
        private readonly HttpClient _http;

        public ApiClient(string baseUrl)
        {
            _http = new HttpClient
            {
                BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/"),
                Timeout = TimeSpan.FromSeconds(15)
            };
        }

        /// <summary>Guarda o JWT recebido no login; vai em todas as chamadas seguintes.</summary>
        public void DefinirToken(string token)
            => _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        public T Get<T>(string rota) => Enviar<T>(HttpMethod.Get, rota, null);
        public T Post<T>(string rota, object? corpo) => Enviar<T>(HttpMethod.Post, rota, corpo);
        public void Post(string rota, object? corpo) => Executar(HttpMethod.Post, rota, corpo);
        public void Put(string rota, object? corpo) => Executar(HttpMethod.Put, rota, corpo);
        public void Patch(string rota, object? corpo) => Executar(HttpMethod.Patch, rota, corpo);
        public void Delete(string rota) => Executar(HttpMethod.Delete, rota, null);

        private T Enviar<T>(HttpMethod metodo, string rota, object? corpo)
        {
            using var resp = Chamar(metodo, rota, corpo);
            try
            {
                var dado = JsonSerializer.Deserialize<T>(resp.Content.ReadAsStream(), Json);
                return dado ?? throw new ServicoException("Resposta vazia da API.");
            }
            catch (JsonException ex)
            {
                throw new ServicoException("Resposta inesperada da API.", ex);
            }
        }

        private void Executar(HttpMethod metodo, string rota, object? corpo)
        {
            using var resp = Chamar(metodo, rota, corpo);
        }

        private HttpResponseMessage Chamar(HttpMethod metodo, string rota, object? corpo)
        {
            using var req = new HttpRequestMessage(metodo, rota.TrimStart('/'));
            if (corpo is not null) req.Content = JsonContent.Create(corpo, options: Json);

            HttpResponseMessage resp;
            try
            {
                resp = _http.Send(req);
            }
            catch (HttpRequestException ex)
            {
                throw new ServicoException(
                    $"Não foi possível conectar à API ({_http.BaseAddress}). Verifique se ela está no ar.", ex);
            }
            catch (TaskCanceledException ex)
            {
                throw new ServicoException("A API demorou demais para responder.", ex);
            }

            if (resp.IsSuccessStatusCode) return resp;

            var erro = ErroDe(resp);
            resp.Dispose();
            throw erro;
        }

        /// <summary>Usa a mensagem { "erro": "..." } da API; na falta dela, um texto padrão pelo código HTTP.</summary>
        private static ServicoException ErroDe(HttpResponseMessage resp)
        {
            var status = (int)resp.StatusCode;
            string? msg = null;
            try
            {
                using var doc = JsonDocument.Parse(resp.Content.ReadAsStream());
                if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                    doc.RootElement.TryGetProperty("erro", out var e))
                    msg = e.GetString();
            }
            catch (JsonException) { /* corpo vazio ou não-JSON */ }

            msg ??= status switch
            {
                401 => "Sessão expirada ou não autenticada. Feche o app e entre novamente.",
                403 => "Você não tem permissão para esta operação.",
                404 => "Item não encontrado.",
                429 => "Muitas tentativas. Aguarde um minuto e tente novamente.",
                >= 500 => "Erro no servidor da API. Tente novamente em instantes.",
                _ => $"Falha na comunicação com a API (HTTP {status})."
            };
            return new ServicoException(msg, null, status);
        }

        public void Dispose() => _http.Dispose();
    }
}
