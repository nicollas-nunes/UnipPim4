namespace HytechAdmin.Data
{
    /// <summary>
    /// Erro de regra de negócio devolvido pela API (HTTP 400 com a mensagem do banco) ou falha de comunicação.
    /// A mensagem já é amigável e pode ser mostrada ao usuário. <see cref="Status"/> guarda o código HTTP, quando houver.
    /// </summary>
    public class ServicoException : Exception
    {
        public int? Status { get; }

        public ServicoException(string mensagem, Exception? inner = null, int? status = null) : base(mensagem, inner)
        {
            Status = status;
        }
    }
}
