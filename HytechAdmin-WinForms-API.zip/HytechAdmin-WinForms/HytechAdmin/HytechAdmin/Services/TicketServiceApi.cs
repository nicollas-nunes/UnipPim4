using HytechAdmin.Data;
using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Tickets via HytechApi (/admin/tickets). Quem responde/encerra é o admin do token.</summary>
    public class TicketServiceApi : ITicketService
    {
        private const string Formato = "dd/MM/yyyy HH:mm";
        private readonly ApiClient _api;
        private readonly AdminLogado _admin;

        public TicketServiceApi(ApiClient api, AdminLogado admin)
        {
            _api = api;
            _admin = admin;
        }

        public List<TicketItem> ObterTickets(bool somenteMeus)
            => _api.Get<List<TicketDto>>("admin/tickets?escopo=" + (somenteMeus ? "meus" : "todos"))
                   .Select(t => new TicketItem
                   {
                       Id = t.Id,
                       Assunto = t.Assunto,
                       Status = t.Status,
                       Materia = t.Materia,
                       Solicitante = t.Solicitante,
                       Destinatario = t.Destinatario,
                       IdDestinatario = t.IdDestinatario,
                       DataAbertura = t.DataAbertura?.ToString(Formato) ?? string.Empty,
                       UltimaMensagem = t.UltimaMensagem?.ToString(Formato) ?? string.Empty,
                       TotalMensagens = t.TotalMensagens,
                       AtribuidoAoAdmin = t.IdDestinatario == _admin.IdUsuario
                   }).ToList();

        public List<TicketMensagemItem> ObterMensagens(int idTicket)
            => _api.Get<List<MensagemDto>>($"admin/tickets/{idTicket}/mensagens")
                   .Select(m => new TicketMensagemItem
                   {
                       Id = m.Id,
                       IdRemetente = m.IdRemetente,
                       Nome = m.Nome,
                       Papel = m.Papel,
                       Texto = m.Texto,
                       DataHora = m.DataHora ?? DateTime.MinValue
                   }).ToList();

        public void Responder(int idTicket, string texto)
            => _api.Post($"admin/tickets/{idTicket}/mensagens", new { texto });

        public void Encerrar(int idTicket)
            => _api.Post($"admin/tickets/{idTicket}/encerrar", null);
    }
}
