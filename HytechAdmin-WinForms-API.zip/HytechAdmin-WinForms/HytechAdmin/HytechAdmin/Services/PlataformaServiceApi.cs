using HytechAdmin.Data;
using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Configuração, métricas e logs via HytechApi (/admin/config, /admin/metricas, /admin/logs).</summary>
    public class PlataformaServiceApi : IPlataformaService
    {
        private readonly ApiClient _api;

        public PlataformaServiceApi(ApiClient api) => _api = api;

        public ConfiguracaoPlataforma ObterConfiguracao()
        {
            var c = _api.Get<ChavesDto>("admin/config/chaves");
            return new ConfiguracaoPlataforma
            {
                ChavesQuestaoFacil = c.QuestaoFacil,
                ChavesQuestaoMedia = c.QuestaoMedia,
                ChavesQuestaoDificil = c.QuestaoDificil,
                ChavesCertificado = c.Certificado
            };
        }

        public void SalvarConfiguracao(ConfiguracaoPlataforma c)
            => _api.Put("admin/config/chaves", new
            {
                questaoFacil = c.ChavesQuestaoFacil,
                questaoMedia = c.ChavesQuestaoMedia,
                questaoDificil = c.ChavesQuestaoDificil,
                certificado = c.ChavesCertificado
            });

        public MetricasPlataforma ObterMetricas()
        {
            var m = _api.Get<MetricasDto>("admin/metricas");
            return new MetricasPlataforma
            {
                TotalUsuarios = m.TotalUsuarios,
                UsuariosAtivos = m.UsuariosAtivos,
                TotalAlunos = m.TotalAlunos,
                TotalProfessores = m.TotalProfessores,
                TotalAdmins = m.TotalAdmins,
                PendentesTotal = m.PendentesTotal,
                CertificadosEmitidos = m.CertificadosEmitidos,
                ChavesDistribuidas = m.ChavesDistribuidas
            };
        }

        public List<LogEntry> ObterLogs()
            => _api.Get<List<LogDto>>("admin/logs?top=100")
                   .Select(l => new LogEntry { Momento = l.DataHora ?? DateTime.MinValue, Mensagem = l.Descricao })
                   .ToList();
    }
}
