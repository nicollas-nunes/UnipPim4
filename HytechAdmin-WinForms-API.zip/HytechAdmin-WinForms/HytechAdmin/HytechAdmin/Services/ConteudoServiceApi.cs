using HytechAdmin.Data;
using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Aulas, questões e desafios via HytechApi (/admin/conteudos).</summary>
    public class ConteudoServiceApi : IConteudoService
    {
        private readonly ApiClient _api;

        public ConteudoServiceApi(ApiClient api) => _api = api;

        public List<ConteudoItem> ObterTodos()
            => _api.Get<List<ConteudoDto>>("admin/conteudos").Select(Mapear).ToList();

        public ConteudoItem? ObterPorId(string id)
        {
            var (tipo, idOrigem) = Separar(id);
            try
            {
                return Mapear(_api.Get<ConteudoDto>($"admin/conteudos/{tipo}/{idOrigem}"));
            }
            catch (ServicoException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        public void Aprovar(string id) => Decidir(id, "aprovado");
        public void Rejeitar(string id) => Decidir(id, "rejeitado");

        public void Remover(string id)
        {
            var (tipo, idOrigem) = Separar(id);
            _api.Delete($"admin/conteudos/{tipo}/{idOrigem}");
        }

        private void Decidir(string id, string decisao)
        {
            var (tipo, idOrigem) = Separar(id);
            _api.Post($"admin/conteudos/{tipo}/{idOrigem}/decisao", new { decisao });
        }

        private static (string tipo, int id) Separar(string idComposto)
        {
            var partes = idComposto.Split(':');
            if (partes.Length != 2 || !int.TryParse(partes[1], out var n))
                throw new ServicoException("Identificador de conteúdo inválido: " + idComposto);
            return (partes[0], n);
        }

        private static ConteudoItem Mapear(ConteudoDto d) => new()
        {
            Id = ConteudoItem.MontarId(d.Tipo, d.Id),
            IdOrigem = d.Id,
            Tipo = d.Tipo == "aula" ? "texto" : d.Tipo,
            Titulo = d.Titulo,
            Materia = d.Materia,
            Autor = d.Autor,
            Status = d.Status,
            Data = d.Data?.ToString("dd/MM/yyyy") ?? string.Empty,
            Dificuldade = FormatarDificuldade(d.Dificuldade),
            Corpo = d.Corpo
        };

        /// <summary>Aceita 'facil', 'Fácil', 'medio', 'difícil'... e devolve o texto de exibição.</summary>
        private static string FormatarDificuldade(string valor)
        {
            var chave = valor.Trim().ToLowerInvariant()
                .Replace('á', 'a').Replace('é', 'e').Replace('í', 'i');
            return chave switch
            {
                "facil" => "Fácil",
                "medio" => "Médio",
                "dificil" => "Difícil",
                _ => valor
            };
        }
    }
}
