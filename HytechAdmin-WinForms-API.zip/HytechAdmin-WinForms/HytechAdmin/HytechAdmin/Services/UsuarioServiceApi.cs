using HytechAdmin.Data;
using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>Usuários via HytechApi (/admin/usuarios). O hash da senha é gerado pela API.</summary>
    public class UsuarioServiceApi : IUsuarioService
    {
        private readonly ApiClient _api;

        public UsuarioServiceApi(ApiClient api) => _api = api;

        public List<Usuario> ObterTodos()
            => _api.Get<List<UsuarioDto>>("admin/usuarios").Select(Mapear).ToList();

        public Usuario? ObterPorId(int id) => ObterTodos().FirstOrDefault(u => u.Id == id);

        public void Adicionar(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Senha))
                throw new ServicoException("Defina uma senha para o novo usuário.");

            usuario.Id = _api.Post<IdDto>("admin/usuarios", Corpo(usuario, usuario.Senha)).Id;
        }

        public void Atualizar(Usuario usuario)
            // senha em branco = mantém a atual
            => _api.Put($"admin/usuarios/{usuario.Id}",
                        Corpo(usuario, string.IsNullOrWhiteSpace(usuario.Senha) ? null : usuario.Senha));

        public void Remover(int id) => _api.Delete($"admin/usuarios/{id}");

        public void AlternarStatus(int id)
        {
            var usuario = ObterPorId(id) ?? throw new ServicoException("Usuário não encontrado.");
            var novo = usuario.EhAtivo ? "inativo" : "ativo";
            _api.Patch($"admin/usuarios/{id}/status", new { status = novo });
        }

        public List<string> ObterEspecialidades()
            => _api.Get<List<MateriaDto>>("admin/materias").Select(m =>
            {
                var icone = m.Icone.Trim();
                return icone.Length > 0 ? $"{icone} {m.Titulo}" : m.Titulo;
            }).ToList();

        private static object Corpo(Usuario u, string? senha) => new
        {
            nome = u.Nome,
            email = u.Email,
            perfil = PerfilParaBanco(u.Perfil),
            especialidade = u.EhProfessor ? u.Especialidade : null,
            senha,
            status = u.Status
        };

        private static Usuario Mapear(UsuarioDto d) => new()
        {
            Id = d.Id,
            Nome = d.Nome,
            Nickname = d.Nickname,
            Email = d.Email,
            Perfil = PerfilDoBanco(d.Perfil),
            Especialidade = d.Especialidade,
            Status = d.Status,
            Cadastro = d.DataCadastro?.ToString("dd/MM/yyyy") ?? string.Empty
        };

        // O banco chama o papel de 'admin'; a interface do app, de 'administrador'.
        private static string PerfilParaBanco(string perfil) => perfil == "administrador" ? "admin" : perfil;
        private static string PerfilDoBanco(string perfil) => perfil == "admin" ? "administrador" : perfil;
    }
}
