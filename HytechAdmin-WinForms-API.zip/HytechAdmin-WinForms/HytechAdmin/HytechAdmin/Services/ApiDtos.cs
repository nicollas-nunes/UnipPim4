namespace HytechAdmin.Services
{
    // Formato JSON devolvido pela HytechApi (camelCase). Cada serviço *Api converte para os modelos do app.

    internal class IdDto { public int Id { get; set; } }

    internal class UsuarioDto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = "";
        public string Nickname { get; set; } = "";
        public string Email { get; set; } = "";
        public string Perfil { get; set; } = "";          // aluno | professor | admin
        public string Especialidade { get; set; } = "";
        public string Status { get; set; } = "";
        public DateTime? DataCadastro { get; set; }
    }

    internal class MateriaDto
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = "";
        public string Icone { get; set; } = "";
    }

    internal class ConteudoDto
    {
        public string Tipo { get; set; } = "";             // aula | questao | desafio
        public int Id { get; set; }
        public string Titulo { get; set; } = "";
        public string Materia { get; set; } = "";
        public string Autor { get; set; } = "";
        public string Status { get; set; } = "";
        public DateTime? Data { get; set; }
        public string Dificuldade { get; set; } = "";
        public string Corpo { get; set; } = "";
    }

    internal class TicketDto
    {
        public int Id { get; set; }
        public string Assunto { get; set; } = "";
        public string Status { get; set; } = "";
        public string Materia { get; set; } = "";
        public string Solicitante { get; set; } = "";
        public string Destinatario { get; set; } = "";
        public int IdDestinatario { get; set; }
        public DateTime? DataAbertura { get; set; }
        public DateTime? UltimaMensagem { get; set; }
        public int TotalMensagens { get; set; }
    }

    internal class MensagemDto
    {
        public int Id { get; set; }
        public int IdRemetente { get; set; }
        public string Nome { get; set; } = "";
        public string Papel { get; set; } = "";
        public string Texto { get; set; } = "";
        public DateTime? DataHora { get; set; }
    }

    internal class ChavesDto
    {
        public int QuestaoFacil { get; set; }
        public int QuestaoMedia { get; set; }
        public int QuestaoDificil { get; set; }
        public int Certificado { get; set; }
    }

    internal class MetricasDto
    {
        public int TotalUsuarios { get; set; }
        public int UsuariosAtivos { get; set; }
        public int TotalAlunos { get; set; }
        public int TotalProfessores { get; set; }
        public int TotalAdmins { get; set; }
        public int PendentesTotal { get; set; }
        public int CertificadosEmitidos { get; set; }
        public long ChavesDistribuidas { get; set; }
    }

    internal class LogDto
    {
        public DateTime? DataHora { get; set; }
        public string Descricao { get; set; } = "";
    }

    internal class LoginRespostaDto
    {
        public string Token { get; set; } = "";
        public LoginUsuarioDto Usuario { get; set; } = new();
    }

    internal class LoginUsuarioDto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = "";
        public string Papel { get; set; } = "";
    }
}
