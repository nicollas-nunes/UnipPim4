using HytechAdmin.Data;
using HytechAdmin.Models;

namespace HytechAdmin.Services
{
    /// <summary>
    /// Login do Admin pela API (POST /auth/login-admin). A API confere a senha (BCrypt), exige papel 'admin'
    /// e conta ativa; o app só recebe o token JWT e o guarda no <see cref="ApiClient"/>.
    /// </summary>
    public class AutenticacaoService
    {
        private readonly ApiClient _api;

        public AutenticacaoService(ApiClient api) => _api = api;

        /// <summary>Retorna o admin autenticado ou null (mesma mensagem para qualquer falha, de propósito).</summary>
        public AdminLogado? Autenticar(string email, string senha)
        {
            LoginRespostaDto resposta;
            try
            {
                resposta = _api.Post<LoginRespostaDto>("auth/login-admin", new { email = email.Trim(), senha });
            }
            catch (ServicoException ex) when (ex.Status is 401 or 403)
            {
                return null;   // senha errada, não é admin ou conta inativa
            }

            if (resposta.Usuario.Papel != "admin") return null;   // defesa extra; a API já filtra

            _api.DefinirToken(resposta.Token);
            return new AdminLogado { IdUsuario = resposta.Usuario.Id, Nome = resposta.Usuario.Nome };
        }
    }
}
