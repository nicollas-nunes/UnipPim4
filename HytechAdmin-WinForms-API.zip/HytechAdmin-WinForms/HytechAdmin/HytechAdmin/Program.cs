using HytechAdmin.Data;
using HytechAdmin.Forms;
using HytechAdmin.Models;
using HytechAdmin.Services;

namespace HytechAdmin
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string baseUrl;
            try
            {
                baseUrl = ApiConfig.LerBaseUrl();
                if (!string.IsNullOrWhiteSpace(baseUrl)) ApiConfig.Validar(baseUrl);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Configuração inválida no appsettings.json:\n" + ex.Message, "HYTECH Admin",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Sem endereço da API: modo demonstração (dados em memória, sem login).
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                var usuarios = new UsuarioServiceMock();
                var conteudos = new ConteudoServiceMock();
                var plataforma = new PlataformaServiceMock(usuarios, conteudos);
                var adminDemo = new AdminLogado { IdUsuario = 10, Nome = "Administrador (demo)" };
                Application.Run(new MainForm(usuarios, conteudos, plataforma, new TicketServiceMock(adminDemo), adminDemo));
                return;
            }

            // Modo API: login obrigatório; somente quem tem papel admin entra.
            using var api = new ApiClient(baseUrl);

            using var login = new LoginForm(new AutenticacaoService(api));
            if (login.ShowDialog() != DialogResult.OK || login.Admin is null) return;

            var admin = login.Admin;
            Application.Run(new MainForm(
                new UsuarioServiceApi(api),
                new ConteudoServiceApi(api),
                new PlataformaServiceApi(api),
                new TicketServiceApi(api, admin),
                admin));
        }
    }
}
